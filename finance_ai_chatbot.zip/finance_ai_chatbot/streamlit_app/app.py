import streamlit as st
import requests

st.title("💬 AI Financial Chatbot          \n@Akeem 2025")


if "chat_history" not in st.session_state:
    st.session_state.chat_history = []

question = st.text_input("Ask a question about Apple's Finance or its Stock Performance:")
ticker = st.text_input("Enter Stock Ticker (e.g., AAPL):", value="AAPL")

if st.button("Ask") and question:
    st.session_state.chat_history.append({"role": "user", "content": question})
    response = requests.post("http://localhost:8000/query", json={"question": question, "ticker": ticker})
    answer = response.json()["response"]
    st.session_state.chat_history.append({"role": "assistant", "content": answer})

for msg in st.session_state.chat_history:
    if msg["role"] == "user":
        st.markdown(f"**You:** {msg['content']}")
    else:
        st.markdown(
            f"**AI:** {msg['content'].replace(chr(10), '<br>')}",
            unsafe_allow_html=True
        )
