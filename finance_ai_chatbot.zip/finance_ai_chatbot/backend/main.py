from fastapi import FastAPI, Request
from backend.rag_pipeline import load_and_index, query_rag
from backend.finance_agent import get_financial_summary
from langchain.chat_models import ChatOpenAI
from langchain.memory import ConversationBufferMemory
from langchain.chains import ConversationalRetrievalChain
import os
from dotenv import load_dotenv

load_dotenv()

db = load_and_index("data/apple_q1_2023.pdf")
app = FastAPI()

memory = ConversationBufferMemory(memory_key="chat_history", return_messages=True)
llm = ChatOpenAI(model_name="gpt-4", temperature=0)
retriever = db.as_retriever()

chat_chain = ConversationalRetrievalChain.from_llm(
    llm=llm,
    retriever=retriever,
    memory=memory,
)

@app.post("/query")
async def query_financial_analyst(request: Request):
    body = await request.json()
    question = body.get("question", "")
    stock = body.get("ticker", "AAPL")

    finance_data = get_financial_summary(stock)

    enriched_query = f"""
Use the following stock data before answering:

{finance_data}

Question: {question}
"""

    response = chat_chain.run(enriched_query)
    return {"response": response}

from backend.finance_agent import get_financial_summary

@app.post("/query")
async def query_financial_analyst(request: Request):
    body = await request.json()
    question = body.get("question", "")
    ticker = body.get("ticker", "AAPL")  # or extract it from the question

    # Get live stock data
    finance_data = get_financial_summary(ticker)

    # Final prompt
    prompt = f"""
You are a financial analyst assistant. Use both the uploaded document and stock market data to answer.

--- Stock Data for {ticker} ---
{finance_data}

--- User Question ---
{question}

--- Answer ---
"""
    
    response = chat_chain.run(prompt)
    return {"response": response}
