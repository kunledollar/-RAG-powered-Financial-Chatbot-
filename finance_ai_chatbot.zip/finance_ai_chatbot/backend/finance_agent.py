import yfinance as yf

def get_financial_summary(ticker):
    stock = yf.Ticker(ticker)
    today = stock.history(period="1d")

    try:
        current_price = today["Close"].values[0]
    except:
        current_price = "N/A"

    info = stock.info
    prev_close = info.get("previousClose", "N/A")
    week52_high = info.get("fiftyTwoWeekHigh", "N/A")
    week52_low = info.get("fiftyTwoWeekLow", "N/A")

    return (
        f"{ticker.upper()} Stock Summary:\n"
        f"Current Price: ${current_price}\n"
        f"Previous Close: ${prev_close}\n"
        f"52-Week High: ${week52_high}\n"
        f"52-Week Low: ${week52_low}"
    )
